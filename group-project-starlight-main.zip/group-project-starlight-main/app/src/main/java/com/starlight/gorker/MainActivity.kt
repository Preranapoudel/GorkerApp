package com.starlight.gorker


import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.starlight.gorker.firebase.AuthViewModel
import com.starlight.gorker.firebase.StoreViewModel
import com.starlight.gorker.ui.composables.CartScreen
import com.starlight.gorker.ui.theme.GorkerTheme
import com.starlight.gorker.ui.composables.LoginScreen
import com.starlight.gorker.ui.composables.ProductListScreen
import com.starlight.gorker.ui.composables.SignUpScreen
import com.starlight.gorker.ui.composables.UserProfileScreen

import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GorkerTheme{
                NavigationMap()
            }
        }
    }
}

@Composable
fun NavigationMap(){
    val navController: NavHostController = rememberNavController()

    val authViewModel: AuthViewModel = hiltViewModel()
    val storeViewModel: StoreViewModel = hiltViewModel()

    val user by authViewModel.userState.collectAsStateWithLifecycle()

    var startingScreen = "login"

    if(user != null){
        startingScreen = "productList"
    }


    NavHost(
        navController = navController,
        startDestination = startingScreen
    ){
        composable("login"){
            val currentUser by authViewModel.userState.collectAsStateWithLifecycle()
            LaunchedEffect(currentUser) {
                Log.d("Login Navigation", "Login launched effect triggered")
                if(currentUser != null){
                    navController.navigate("productList"){
                        popUpTo("login"){inclusive = true}
                    }
                }
            }
            LoginScreen(
                authViewModel = authViewModel,
                onNavigateToSignUp = {navController.navigate("signUp")}
            )
        }

        composable("signUp"){
            val currentUser by authViewModel.userState.collectAsStateWithLifecycle()
            LaunchedEffect(currentUser) {
                if(currentUser != null){
                    navController.navigate("productList"){
                        popUpTo("login"){inclusive = true}
                    }
                }
            }
            SignUpScreen(
                authViewModel = authViewModel,
                onNavigateBack = { navController.popBackStack() },
            )
        }

        composable("productList"){
            val currentUser by authViewModel.userState.collectAsStateWithLifecycle()
            LaunchedEffect(currentUser) {
                if (currentUser == null){
                    navController.navigate("login"){
                        popUpTo("productList"){inclusive = true}
                    }
                }
            }
            ProductListScreen(
                viewModel = storeViewModel,
                onNavigateToCart = {navController.navigate("cart")},
                onNavigateToProfile = {navController.navigate("profile")}
            )
        }

        composable("cart"){
            val currentUser by authViewModel.userState.collectAsStateWithLifecycle()
            LaunchedEffect(currentUser) {
                if(currentUser == null){
                    navController.navigate("login"){
                        popUpTo("productList"){inclusive = true}
                    }
                }
            }
            CartScreen(
                viewModel = storeViewModel
            )
        }

         composable("profile"){
            val currentUser by authViewModel.userState.collectAsStateWithLifecycle()
             LaunchedEffect(currentUser) {
                if(currentUser == null){
                    navController.navigate("login"){
                        popUpTo("productList")
                    }
                }
            }
             UserProfileScreen(
                 storeViewModel   = storeViewModel,
                 authViewModel    = authViewModel,
                 onNavigateBack   = { navController.popBackStack() },
                 onSignOut        = {

                     navController.navigate("login") {
                         popUpTo(0)
                     }
                 }
             )
        }

    }
}


