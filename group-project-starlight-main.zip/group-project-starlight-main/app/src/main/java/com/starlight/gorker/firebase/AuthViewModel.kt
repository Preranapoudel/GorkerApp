package com.starlight.gorker.firebase

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.ktx.userProfileChangeRequest
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: FirebaseAuthRepository
) : ViewModel() {

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    val userState = authRepository.getAuthStateFlow()


    fun signIn(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _error.value = "Email and password must not be empty."
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            authRepository
                .signIn(email, password)
                .onFailure { ex ->
                    _error.value = ex.message ?: "Sign-in failed"
                }
            _isLoading.value = false
        }
    }


    fun signUp(username: String, email: String, password: String) {
        if (username.isBlank() || email.isBlank() || password.isBlank()) {
            _error.value = "All fields are required"
            return
        }

        viewModelScope.launch {
            _isLoading.value = true
            _error.value = null

            authRepository.createUser(email, password)
                .onSuccess {
                    authRepository.getCurrentUser()?.updateProfile(
                        userProfileChangeRequest { displayName = username }
                    )?.addOnFailureListener { ex ->
                        _error.value = ex.message
                    }
                }
                .onFailure { ex ->
                    _error.value = ex.message ?: "Sign-up failed"
                }

            _isLoading.value = false
        }
    }

    fun signOut() {
        authRepository.signOut()
    }
}
