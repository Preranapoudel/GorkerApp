package com.starlight.gorker.firebase.data

import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.ServerTimestamp
import java.util.Date

data class Product(
    @DocumentId val id: String = "",
    val name: String = "",
    val description: String = "",
    val category: String = "",
    val price: Double = 0.0,
    val imageUrl: String = ""
)

data class OrderItem(
    val productID: String = "",
    val name: String = "",
    val price: Double = 0.0,
    val quantity: Int = 0,
    val imageUrl: String = ""
)

data class CartItem(
    @DocumentId val productID: String = "",
    val quantity: Int = 0,
    val price: Double = 0.0
)

data class Order(
    @DocumentId val id: String = "",
    @ServerTimestamp val timestamp: Date? = null,
    val items: List<OrderItem> = listOf(),
    val totalPrice: Double = 0.0
)
