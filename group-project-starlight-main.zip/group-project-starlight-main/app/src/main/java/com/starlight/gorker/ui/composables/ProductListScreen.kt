package com.starlight.gorker.ui.composables

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.starlight.gorker.R
import com.starlight.gorker.firebase.StoreViewModel
import com.starlight.gorker.firebase.data.Product

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductListScreen(
    viewModel: StoreViewModel,
    onNavigateToCart: () -> Unit,
    onNavigateToProfile: () -> Unit
){
    val products by viewModel.products.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val isLoading by viewModel.isLoading.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Image(
                        painter = painterResource(id = R.drawable.gorker_logo),
                        contentDescription = "Gorker Logo",
                        modifier = Modifier.height(32.dp)
                    )
                }
            )
        },
        bottomBar = {
            BottomAppBar(
                onNavigateToProfile = onNavigateToProfile,
                onNavigateToCart = onNavigateToCart
            )
        }
    ){ padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding)
        ){
            if(isLoading){
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center){
                    CircularProgressIndicator()
                }
            }
            else{
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ){
                    items(products, key = {product -> product.id}) {product ->
                        val quantityInCart = cartItems.find {cartItem -> cartItem.productID == product.id}?.quantity ?: 0

                        ProductRow(
                            product = product,
                            quantityInCart = quantityInCart,
                            onIncrement = {viewModel.addToCart(product.id)},
                            onDecrement = {viewModel.decrementCartItem(product.id)}
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalGlideComposeApi::class)
@Composable
fun ProductRow(
    product: Product,
    quantityInCart: Int,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    modifier: Modifier = Modifier
){
    Card(modifier = modifier.fillMaxWidth()){
        Row(
            modifier = Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ){
            GlideImage(
                model = product.imageUrl,
                contentDescription = product.name,
                modifier = Modifier.size(80.dp).padding(end = 12.dp),
                contentScale = ContentScale.Crop
            )
            Column(
                modifier = Modifier.weight(1f)
            ){
                Text(
                    text = product.name,
                    fontWeight = FontWeight.Bold
                )

                Spacer(Modifier.height(4.dp))

                Text(
                    text = product.description
                )

                Spacer(Modifier.height(4.dp))
                
                Text(
                    text = "$" + product.price.toString()
                )
            }
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ){
                IconButton(onClick = onIncrement){
                    Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Add item to cart")
                }

                if(quantityInCart > 0){
                    Text(
                        text = quantityInCart.toString()
                    )
                }

                if(quantityInCart > 0){
                    IconButton(onClick = onDecrement) {
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Remove item from cart")
                    }
                }
                else{
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }

    }
}

@Composable
fun BottomAppBar(
    onNavigateToProfile: () -> Unit,
    onNavigateToCart: () -> Unit,
    modifier: Modifier = Modifier
){
    BottomAppBar(
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.primaryContainer,
        contentColor = MaterialTheme.colorScheme.onPrimaryContainer
    ){
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ){
            IconButton(onClick = onNavigateToProfile){
                Icon(Icons.Default.AccountCircle, contentDescription = "Profile")
            }
            IconButton(onClick = onNavigateToCart) {
                Icon(Icons.Default.ShoppingCart, contentDescription = "Cart")
            }
        }
    }
}
