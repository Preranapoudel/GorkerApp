package com.starlight.gorker.firebase

import android.util.Log
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.firestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.snapshots
import com.google.firebase.firestore.toObject
import com.google.firebase.firestore.toObjects
import com.google.firebase.ktx.Firebase
import com.starlight.gorker.firebase.data.CartItem
import com.starlight.gorker.firebase.data.Order
import com.starlight.gorker.firebase.data.OrderItem
import com.starlight.gorker.firebase.data.Product
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirestoreRepository @Inject constructor() {
    private val firestore: FirebaseFirestore = Firebase.firestore

    private val productsCollection = firestore.collection("products")
    private fun userCartCollection(userID: String): CollectionReference =
        firestore.collection("users").document(userID).collection("cart")
    private fun userOrdersCollection(userID: String) : CollectionReference =
        firestore.collection("users").document(userID).collection("orders")

    fun getProductData(): Flow<List<Product>> {
        return productsCollection
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects<Product>()
            }
    }

    private suspend fun getProductByID(productID: String): Result<Product?>{
        try{
            val snapshot = productsCollection.document(productID).get().await()
            return Result.success(snapshot.toObject<Product>())
        } catch(e: Exception){
            Log.e("FirestoreRepository", "Error fetching product", e)
            return Result.failure(e)
        }
    }

    fun getCartData(userID: String): Flow<List<CartItem>>{
        return userCartCollection(userID)
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects<CartItem>()
            }
    }

    suspend fun addToCart(userID: String, productID: String, quantity: Int): Result<Unit>{
        if (quantity <= 0)
            return Result.failure(Exception("Cannot enter a negative quantity"))
        try{
            val cartItem = userCartCollection(userID).document(productID)
            val product = getProductByID(productID).getOrNull()
                ?: return Result.failure(Exception("Could not find product details to add to cart"))
            val item = CartItem(productID = productID, quantity = quantity, price = product.price)
            cartItem.set(item, SetOptions.merge()).await()
            return Result.success(Unit)
        } catch (e: Exception){
            Log.e("FirestoreRepository", "Error adding to cart", e)
            return Result.failure(e)
        }
    }

    suspend fun incrementCartItem(userID: String, productID: String): Result<Unit>{
        try{
            val cartItem = userCartCollection(userID).document(productID)
            firestore.runTransaction{ transaction ->
                val snapshot = transaction.get(cartItem)
                val currentQuantity = snapshot.toObject<CartItem>()?.quantity ?: 0
                transaction.update(cartItem, "quantity", currentQuantity + 1)
            }.await()
            return Result.success(Unit)
        }catch (e: Exception){
            Log.e("FirestoreRepository", "Error incrementing cart", e)
            return Result.failure(e)
        }
    }

    suspend fun decrementCartItem(userID: String, productID: String): Result<Unit>{
        try{
            val cartItem = userCartCollection(userID).document(productID)
            firestore.runTransaction{ transaction ->
                val snapshot = transaction.get(cartItem)
                val currentQuantity = snapshot.toObject<CartItem>()?.quantity ?: 0
                if (currentQuantity > 1){
                    transaction.update(cartItem, "quantity", currentQuantity - 1)
                }
                else {
                    transaction.delete(cartItem)
                }
            }.await()
            return Result.success(Unit)
        }catch (e: Exception){
            Log.e("FirestoreRepository", "Error decrementing cart", e)
            return Result.failure(e)
        }
    }

    suspend fun removeFromCart(userID: String, productID: String): Result<Unit>{
        try{
            userCartCollection(userID).document(productID).delete().await()
            return Result.success(Unit)
        } catch (e: Exception){
            Log.e("FirestoreRepository", "Error removing item from cart")
            return Result.failure(e)
        }
    }

    private suspend fun clearCart(userID: String): Result<Unit>{
        try{
            val cartItems = userCartCollection(userID).get().await()
            val batch = firestore.batch()
            cartItems.documents.forEach { item ->
                batch.delete(item.reference)
            }
            batch.commit().await()
            return Result.success(Unit)
        } catch(e: Exception){
            Log.e("FirestoreRepository", "Error clearing cart", e)
            return Result.failure(e)
        }
    }

    fun getOrderData(userID: String): Flow<List<Order>>{
        return userOrdersCollection(userID)
            .orderBy("timestamp")
            .snapshots()
            .map { snapshot ->
                snapshot.toObjects<Order>()
            }
    }

    suspend fun createOrder(userID: String, cartItems: List<CartItem>, products: List<Product>): Result<String>{
        if (cartItems.isEmpty()){
            return Result.failure(Exception("Cart is empty"))
        }
        try{
            val orderItems: List<OrderItem> = cartItems.mapNotNull { item ->
                val product = products.find {it.id == item.productID}
                if(product != null){
                    OrderItem(
                        productID = item.productID,
                        name = product.name,
                        price = product.price,
                        quantity = item.quantity,
                        imageUrl = product.imageUrl
                    )
                }
                else {
                    Log.e ("StoreRepository", "Product not found")
                    null
                }
            }

            var calculatedTotal = 0.0
            for (item in orderItems){
                calculatedTotal += (item.price * item.quantity)
            }

            val newOrder = userOrdersCollection(userID).document()
            val order = Order(
                id = newOrder.id,
                items = orderItems,
                totalPrice = calculatedTotal,
                timestamp = null
            )

            newOrder.set(order).await()
            clearCart(userID)
            return Result.success(newOrder.id)
        } catch(e: Exception){
            Log.e("StoreRepository", "Error creating order", e)
            return Result.failure(e)
        }
    }




}