package com.starlight.gorker.firebase

import android.util.Log
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirebaseAuthRepository @Inject constructor () {

    private val auth: FirebaseAuth = Firebase.auth

    private val authStateFlow = MutableStateFlow(auth.currentUser)
    private val authStateListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        Log.d("AuthStateUpdating", "AuthStateListener was triggered, user: ${firebaseAuth.currentUser}")
        authStateFlow.value = firebaseAuth.currentUser
    }

    init {
        Log.d("NavigationDebug", "FirebaseAuthRepository singleton init. Adding AuthStateListener.")
        auth.addAuthStateListener(authStateListener)
        Log.d("NavigationDebug", "Initial user in repo init: ${auth.currentUser?.uid}")
    }

    fun getAuthStateFlow(): StateFlow<FirebaseUser?> {
        return authStateFlow.asStateFlow()
    }

    suspend fun signIn(email: String, password: String): Result<AuthResult>{
        return try{
            val result = auth.signInWithEmailAndPassword(email, password).await()
            Result.success(result)
        } catch(e: Exception){
            Log.e("SignIn", "Sign-In Failed", e)
            Result.failure(e)
        }
    }

    suspend fun createUser(email: String, password: String): Result<AuthResult>{
        return try{
            val result = auth.createUserWithEmailAndPassword(email, password).await()
            Result.success(result)
        } catch (e: Exception){
            Log.e("UserCreation", "Failed to Create User", e)
            Result.failure(e)
        }
    }

    fun signOut(){
        auth.signOut()
    }

    fun getCurrentUser(): FirebaseUser? {
        return auth.currentUser
    }

}