package com.starlight.gorker.ui.composables

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import com.starlight.gorker.firebase.StoreViewModel
import com.starlight.gorker.firebase.data.CartItem
import com.starlight.gorker.firebase.data.Product


@Composable
fun CartScreen(viewModel: StoreViewModel) {
    val product by viewModel.products.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val totalPrice by viewModel.cartTotalPrice.collectAsStateWithLifecycle()
    val context = LocalContext.current
    Column(modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)) {
        Text("Your Shopping Cart", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        LazyColumn(modifier = Modifier.weight(1f)) {
            items(cartItems, key = { item -> item.productID}){ item -> val product = product.find { product -> product.id == item.productID}
                if (product != null) {
                    CartItemRow(
                        item = item,
                        product = product,
                        onIncrement = {viewModel.incrementCartItem(item.productID) },
                        onDecrement = {viewModel.decrementCartItem(item.productID) },
                        onRemove = {viewModel.removeFromCart(item.productID)}
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text("Total: $${"%.2f".format(totalPrice)}", style = MaterialTheme.typography.titleMedium)

        Button(
            onClick = {
                viewModel.placeOrder()
                Toast.makeText(context, "Order Placed Sucessfully!", Toast.LENGTH_SHORT).show()
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ){
            Text("Place Order")
        }
    }
}


@OptIn(ExperimentalGlideComposeApi::class)
@Composable
fun CartItemRow(
    item: CartItem,
    product: Product,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onRemove: () -> Unit
){
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically,
            modifier =  Modifier.weight(1f)) {
            GlideImage(model = product.imageUrl,
                contentDescription = product.name,
                modifier = Modifier.size(80.dp).padding(end = 8.dp))
            Column(modifier = Modifier.weight(1f)){
                Text(text = "Item Name: ${product.name}", style = MaterialTheme.typography.bodyLarge)
                Text(text = "Price: $${product.price}", style = MaterialTheme.typography.bodyLarge)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onDecrement){
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Decrement")
                }
                Text("${item.quantity}", style = MaterialTheme.typography.bodyLarge)
                IconButton(onClick = onIncrement) {
                    Icon(Icons.Default.KeyboardArrowUp, contentDescription = "Increment")
                }
            }
            IconButton(onClick = onRemove) {
                Icon(Icons.Default.Delete, contentDescription = "Remove")
            }
        }
    }
}
