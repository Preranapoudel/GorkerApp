package com.starlight.gorker.firebase

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.google.firebase.auth.FirebaseUser
import com.starlight.gorker.firebase.data.CartItem
import com.starlight.gorker.firebase.data.Order
import com.starlight.gorker.firebase.data.Product
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.WhileSubscribed
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.handleCoroutineException
import kotlinx.coroutines.launch
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class StoreViewModel @Inject constructor(
    private val storeRepository: FirestoreRepository,
    private val authRepository: FirebaseAuthRepository
): ViewModel() {
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _error = MutableStateFlow("")
    val error: StateFlow<String> = _error.asStateFlow()

    val userIDState: StateFlow<String?> = authRepository.getAuthStateFlow()
        .map { firebaseUser -> firebaseUser?.uid }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = authRepository.getCurrentUser()?.uid
        )

    val currentUser: StateFlow<FirebaseUser?> = authRepository.getAuthStateFlow()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = authRepository.getCurrentUser()
        )

    val products: StateFlow<List<Product>> = storeRepository.getProductData()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val cartItems: StateFlow<List<CartItem>> = userIDState
        .flatMapLatest { userID ->
            if (userID != null) {
                storeRepository.getCartData(userID)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val cartTotalPrice: StateFlow<Double> = cartItems
        .map { items ->
            var currentTotal = 0.0
            items.forEach { item ->
                val itemTotal = item.price * item.quantity
                currentTotal += itemTotal
            }
            currentTotal
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0.0
        )

    val orders: StateFlow<List<Order>> = userIDState
        .flatMapLatest { userID ->
            if (userID != null) {
                storeRepository.getOrderData(userID)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun addToCart(productID: String) {
        val userID = userIDState.value ?: return

        var itemInCart = false
        if (cartItems.value.find { it.productID == productID } != null)
            itemInCart = true

        viewModelScope.launch {
            if (itemInCart) {
                storeRepository.incrementCartItem(userID, productID)
            } else {
                storeRepository.addToCart(userID, productID, 1)
            }
        }
    }

    fun incrementCartItem(productID: String){
        val userID = userIDState.value ?: return
        viewModelScope.launch {
            storeRepository.incrementCartItem(userID, productID)
        }
    }

    fun decrementCartItem(productID: String){
        val userID = userIDState.value ?: return
        viewModelScope.launch {
            storeRepository.decrementCartItem(userID, productID)
        }
    }

    fun removeFromCart(productID: String){
        val userID = userIDState.value ?: return
        viewModelScope.launch {
            storeRepository.removeFromCart(userID, productID)
        }
    }

    fun placeOrder(){
        val userID = userIDState.value
        val currentCartItems = cartItems.value
        val currentProducts = products.value

        if (userID == null){
            _error.value = "Need to login to place an order."
            return
        }

        if (currentCartItems.isEmpty()){
            _error.value = "No items in cart"
            return
        }


        viewModelScope.launch {
            _isLoading.value = true
            _error.value = ""

            val result = storeRepository.createOrder(
                userID = userID,
                cartItems = currentCartItems,
                products = currentProducts,
            )

            result.onFailure {
                _error.value = "Failed to place order"
            }

            _isLoading.value = false
        }
    }

}